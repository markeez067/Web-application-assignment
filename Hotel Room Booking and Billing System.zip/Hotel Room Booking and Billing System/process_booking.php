<?php
// Secure Request Guard Configuration Matrix
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Direct access to this script is strictly prohibited.");
}

// 1. Capture payload data cleanly via $_POST parameters
$fullName       = isset($_POST['fullName']) ? htmlspecialchars(trim($_POST['fullName'])) : '';
$nationalId     = isset($_POST['nationalId']) ? htmlspecialchars(trim($_POST['nationalId'])) : '';
$email          = isset($_POST['email']) ? htmlspecialchars(trim($_POST['email'])) : '';
$phone          = isset($_POST['phone']) ? htmlspecialchars(trim($_POST['phone'])) : '';
$checkInDate    = isset($_POST['checkInDate']) ? htmlspecialchars(trim($_POST['checkInDate'])) : '';
$nights         = isset($_POST['nights']) ? intval($_POST['nights']) : 0;
$roomType       = isset($_POST['roomType']) ? htmlspecialchars(trim($_POST['roomType'])) : '';
$guests         = isset($_POST['guests']) ? intval($_POST['guests']) : 0;
$breakfast      = isset($_POST['breakfast']) ? "Yes" : "No";
$airportTransfer = isset($_POST['airportTransfer']) ? "Yes" : "No";
$lateCheckout   = isset($_POST['lateCheckout']) ? "Yes" : "No"; // Custom Code Component 9

// 2 & 3. Mandated Basic Server-Side Integrity Validation Routine
if (empty($fullName) || empty($email) || empty($phone) || empty($roomType) || $nights < 1 || $guests < 1) {
    die("<h3>Server-Side Validation Failure: Essential application inputs missing or corrupted.</h3>");
}

// 4. Autonomous Price Verification (Independent Server calculations)
$roomRates = ["Single" => 3500, "Double" => 5000, "Family" => 7500];
if (!array_key_exists($roomType, $roomRates)) {
    die("Invalid room type processed.");
}

$roomCost = $roomRates[$roomType] * $nights;
$breakfastCost = ($breakfast === "Yes") ? (700 * $guests * $nights) : 0;
$transferCost = ($airportTransfer === "Yes") ? 2000 : 0;
$lateCheckoutCost = ($lateCheckout === "Yes") ? 2000 : 0; // Cost implementation assignment rules

// Calculate full comprehensive server validated total balance
$totalAmountPayable = $roomCost + $breakfastCost + $transferCost + $lateCheckoutCost;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Booking Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f9;
            padding: 40px;
            color: #333;
        }

        .receipt-card {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
            border-top: 8px solid #18bc9c;
        }

        .success-title {
            color: #18bc9c;
            text-align: center;
            font-size: 1.6rem;
            letter-spacing: 1px;
            margin-bottom: 20px;
        }

        .receipt-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px dashed #e2e8f0;
        }

        .receipt-row.total {
            border-top: 2px solid #2c3e50;
            border-bottom: none;
            font-size: 1.4rem;
            font-weight: bold;
            color: #2c3e50;
            margin-top: 15px;
        }

        .thank-you-note {
            text-align: center;
            margin-top: 30px;
            font-style: italic;
            color: #7f8c8d;
        }

        .back-nav {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #18bc9c;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>

<body>

    <div class="receipt-card">
        <div class="success-title">BOOKING CONFIRMED</div>

        <div class="receipt-row"><span>Customer:</span> <strong><?php echo $fullName; ?></strong></div>
        <div class="receipt-row"><span>ID / Passport:</span> <span><?php echo !empty($nationalId) ? $nationalId : 'N/A'; ?></span></div>
        <div class="receipt-row"><span>Email:</span> <span><?php echo $email; ?></span></div>
        <div class="receipt-row"><span>Room:</span> <strong><?php echo $roomType; ?> Room</strong></div>
        <div class="receipt-row"><span>Guests:</span> <span><?php echo $guests; ?></span></div>
        <div class="receipt-row"><span>Number of Nights:</span> <span><?php echo $nights; ?></span></div>
        <div class="receipt-row"><span>Breakfast Included:</span> <span><?php echo $breakfast; ?></span></div>
        <div class="receipt-row"><span>Airport Transfer:</span> <span><?php echo $airportTransfer; ?></span></div>
        <div class="receipt-row"><span>Late Checkout Option:</span> <span><?php echo $lateCheckout; ?></span></div>

        <div class="receipt-row total">
            <span>TOTAL AMOUNT:</span>
            <span>KSh <?php echo number_format($totalAmountPayable); ?></span>
        </div>

        <div class="thank-you-note">
            Thank you for choosing Sunrise Hotel.<br>
            Your luxury getaway awaits.
        </div>

        <a href="booking.html" class="back-nav">← Back to Booking</a>
    </div>

</body>

</html>