document.addEventListener("DOMContentLoaded", function () {
    // Input Fields Element References
    const form = document.getElementById("bookingForm");
    const fullName = document.getElementById("fullName");
    const email = document.getElementById("email");
    const phone = document.getElementById("phone");
    const nights = document.getElementById("nights");
    const roomType = document.getElementById("roomType");
    const guests = document.getElementById("guests");
    const breakfast = document.getElementById("breakfast");
    const airportTransfer = document.getElementById("airportTransfer");
    const lateCheckout = document.getElementById("lateCheckout");

    // UI Dynamic Alert Element
    const capacityInfo = document.getElementById("capacityInfo");

    // Event Binding Configuration (Fulfilling Task 5: change, input, submit)
    if (roomType) roomType.addEventListener("change", handleRoomSelectionChanges);
    if (nights) nights.addEventListener("input", calculateBill);
    if (guests) guests.addEventListener("input", calculateBill);
    if (breakfast) breakfast.addEventListener("change", calculateBill);
    if (airportTransfer) airportTransfer.addEventListener("change", calculateBill);
    if (lateCheckout) lateCheckout.addEventListener("change", calculateBill);
    if (form) form.addEventListener("submit", validateBooking);

    // Max Room Occupancy Index Definition
    const roomCapacities = { "Single": 1, "Double": 2, "Family": 4 };
    const roomRates = { "Single": 3500, "Double": 5000, "Family": 7500 };

    // Task 3: Dynamic Layout and UI Control Handling Function
    function handleRoomSelectionChanges() {
        const selectedRoom = roomType.value;
        if (selectedRoom && roomCapacities[selectedRoom]) {
            const maxGuests = roomCapacities[selectedRoom];
            capacityInfo.style.display = "block";
            capacityInfo.innerHTML = `<strong>Room Notice:</strong> Maximum occupancy for a ${selectedRoom} room is ${maxGuests} guest(s).`;
        } else {
            capacityInfo.style.display = "none";
        }
        calculateBill();
    }

    // Task 4: Interactive Invoice and Cost Assessment Loop Logic
    function calculateBill() {
        const room = roomType.value;
        const totalNights = parseInt(nights.value) || 0;
        const totalGuests = parseInt(guests.value) || 0;

        let totalAmount = 0;

        if (room && roomRates[room] && totalNights > 0) {
            // Base Tariff Fee Computation
            totalAmount += roomRates[room] * totalNights;

            // Breakfast Options Cumulative Array Addition
            if (breakfast && breakfast.checked) {
                totalAmount += (700 * totalGuests * totalNights);
            }

            // Flat Fee Transfer Inclusion Matrix
            if (airportTransfer && airportTransfer.checked) {
                totalAmount += 2000;
            }

            // Student Custom Code 9 Factor: Late Checkout Surcharge Implementation
            if (lateCheckout && lateCheckout.checked) {
                totalAmount += 2000;
            }
        }

        const billDisplay = document.getElementById("liveBillDisplay");
        if (billDisplay) {
            billDisplay.innerText = `Estimated Total: KSh ${totalAmount.toLocaleString()}`;
        }
    }

    // Task 2: Standard JavaScript client Form Verification Framework
    function validateBooking(event) {
        let isValid = true;

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const phoneRegex = /^\d{10}$/;


        // 1. Full name checklist verification logic
        if (fullName && fullName.value.trim() === "") {
            document.getElementById("nameError").style.display = "block";
            isValid = false;
        } else if (document.getElementById("nameError")) {
            document.getElementById("nameError").style.display = "none";
        }

        // 2. Email structural layout configuration checks
        if (email && !emailRegex.test(email.value.trim())) {
            document.getElementById("emailError").style.display = "block";
            isValid = false;
        } else if (document.getElementById("emailError")) {
            document.getElementById("emailError").style.display = "none";
        }

        // 3. Phone parameter size analysis rules
        if (phone && !phoneRegex.test(phone.value.trim())) {
            document.getElementById("phoneError").style.display = "block";
            isValid = false;
        } else if (document.getElementById("phoneError")) {
            document.getElementById("phoneError").style.display = "none";
        }

        // 4. Nights ceiling window constraints monitoring logic
        const numNights = parseInt(nights.value);
        if (isNaN(numNights) || numNights < 1 || numNights > 14) {
            document.getElementById("nightsError").style.display = "block";
            isValid = false;
        } else if (document.getElementById("nightsError")) {
            document.getElementById("nightsError").style.display = "none";
        }

        // 5. Room Type selection validation
        if (roomType && roomType.value === "") {
            document.getElementById("roomError").style.display = "block";
            isValid = false;
        } else if (document.getElementById("roomError")) {
            document.getElementById("roomError").style.display = "none";
        }

        // 6. Guests boundary checks & room capacity match analysis
        const numGuests = parseInt(guests.value);
        const selectedRoom = roomType ? roomType.value : "";
        if (isNaN(numGuests) || numGuests <= 0) {
            if (document.getElementById("guestsError")) {
                document.getElementById("guestsError").innerText = "Guests must be greater than zero.";
                document.getElementById("guestsError").style.display = "block";
            }
            isValid = false;
        } else if (selectedRoom && numGuests > roomCapacities[selectedRoom]) {
            if (document.getElementById("guestsError")) {
                document.getElementById("guestsError").innerText = `Warning: Room capacity exceeded! Max allowed is ${roomCapacities[selectedRoom]}.`;
                document.getElementById("guestsError").style.display = "block";
            }
            isValid = false;
        } else if (document.getElementById("guestsError")) {
            document.getElementById("guestsError").style.display = "none";
        }

        // Interrupt dispatch handler routine if constraints break rules
        if (!isValid) {
            event.preventDefault();
        }
    }
});
